
% Create an array to save all feature vectors for 20 images
Set=[];
% Create a text file to save training set
fileID = fopen('testset.txt','at');
% Using a for loop to save feature vectors automatically
for w='a':'c';
    P=strcat(w,'.pgm');
    Q=imread(P);
    % change image type to double in order to fit 'sqrt' function
    Z=im2double(Q);
    % get average pixel each row as a feature vector
    X=mean(Z.');
    % using (:) to save pixels in one line 112*1
    W=X(:);
    Set=W';
    % print file name as the trainlable
    fprintf(fileID,'%s \t',w);
    fmt=[repmat('%f\t',1,111),'%f\n'];
    % print feature vectors for each face following the file name 
    fprintf(fileID,fmt,Set);
end
fclose(fileID);

